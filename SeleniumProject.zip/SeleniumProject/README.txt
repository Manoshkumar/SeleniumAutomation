1. PyChram IDE is used with python and selenium
2. The test data is fetched from the excel sheet
3. the test results are update to the excel sheet back.