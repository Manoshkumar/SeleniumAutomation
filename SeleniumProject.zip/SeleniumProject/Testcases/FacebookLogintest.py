from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
import time
import xlutils

driver = webdriver.Chrome(executable_path='C:/Users/prems/PycharmProjects/SeleniumProject/Drivers/chromedriver.exe')
driver.implicitly_wait(2)
driver.get("https://www.facebook.com/")
driver.maximize_window()

datapath="C:/Users/prems/PycharmProjects/SeleniumProject/TestData/Data.xlsx"
rows=xlutils.getRowCount(datapath,'Sheet2')

for r in range(2,rows+1):
    emailid = xlutils.readdata(datapath,"Sheet2",r,3)
    passwordnum = xlutils.readdata(datapath,"Sheet2",r,4)
    driver.find_element_by_id("email").clear()
    driver.find_element_by_id("email").send_keys(emailid)
    driver.find_element_by_id("pass").send_keys(passwordnum)
    time.sleep(5)
    driver.find_element_by_id("u_0_b").click()
    time.sleep(10)
    errormsg = driver.find_element_by_link_text("Sign up for an account.").text
    if errormsg == "Sign up for an account.":
        xlutils.writedata(datapath, "Sheet2", r, 5, "Test Passed")
    else:
        xlutils.writedata(datapath, "Sheet2", r, 5, "Test Failed")
driver.close()