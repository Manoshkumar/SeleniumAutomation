import openpyxl

def getRowCount(datapath,sheetname):
    workbook = openpyxl.load_workbook(datapath)
    sheet = workbook.get_sheet_by_name(sheetname)
    return(sheet.max_row)

def getColumnCount(datapath,sheetname):
    workbook = openpyxl.load_workbook(datapath)
    sheet = workbook.get_sheet_by_name(sheetname)
    return(sheet.max_column)

def readdata(datapath,sheetname,rownum,colnum):
    workbook = openpyxl.load_workbook(datapath)
    sheet = workbook.get_sheet_by_name(sheetname)
    return sheet.cell(row=rownum, column=colnum).value

def writedata(datapath,sheetname,rownum,colnum,data):
    workbook = openpyxl.load_workbook(datapath)
    sheet = workbook.get_sheet_by_name(sheetname)
    sheet.cell(row=rownum, column=colnum).value = data
    workbook.save(datapath)