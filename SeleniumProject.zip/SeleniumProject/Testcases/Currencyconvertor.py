from selenium.common.exceptions import NoSuchElementException
from selenium import webdriver
import time
import xlutils



driver = webdriver.Chrome(executable_path='C:/Users/prems/PycharmProjects/SeleniumProject/Drivers/chromedriver.exe')
driver.implicitly_wait(2)
driver.get("http://www.xe.com/currencyconverter/")
driver.maximize_window()

datapath="C:/Users/prems/PycharmProjects/SeleniumProject/TestData/Data.xlsx"
rows=xlutils.getRowCount(datapath,'Sheet1')

for r in range(2,rows+1):
    amtvalue = xlutils.readdata(datapath,"Sheet1",r,2)
    driver.find_element_by_id("amount").clear()
    driver.find_element_by_id("amount").send_keys(amtvalue)
    time.sleep(2)
    driver.find_element_by_id("from").send_keys("EUR")
    time.sleep(2)
    driver.find_element_by_id("to").send_keys("GBP")
    time.sleep(2)
    driver.find_element_by_xpath("//*[@id='converterForm']/form/button[2]").click()
    driver.find_element_by_id("yie-close-button-40c4a77a-7600-55c5-a4a6-f8a94f4ce708").click()
    time.sleep(2)
    try:
        element=driver.find_element_by_id("main-heading")
        xlutils.writedata(datapath,"Sheet1",r,3,"Test Passed")
    except NoSuchElementException:
        xlutils.writedata(datapath,"Sheet1",r,3,"Test Failed")
driver.close()

# element=driver.find_element_by_name("From")
# drp=Select(element)
# drp.select_by_visible_text('EUR')




